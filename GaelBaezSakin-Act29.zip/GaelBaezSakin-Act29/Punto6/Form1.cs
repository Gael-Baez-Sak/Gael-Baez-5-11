using Microsoft.VisualBasic.Logging;

namespace Punto6
{
    //Consigna: Disponer tres CheckBox con productos y precios fijos.Un Button
    //"Calcular Total" debe evaluar los controles seleccionados(Checked == true), sumar
    //sus costos y mostrar el monto final en un Label.
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int total = 0;

            if (checkBox1.Checked == true)
            {
                total += 1500;
            }
            if (checkBox2.Checked == true)
            {
                total += 2000;
            }
            if (checkBox3.Checked == true)
            {
                total += 3000;
            }

            label1.Text = "Total: $" + total.ToString();
        }
    }
}
