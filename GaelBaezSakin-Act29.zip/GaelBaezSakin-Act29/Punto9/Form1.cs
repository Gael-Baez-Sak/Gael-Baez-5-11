using Microsoft.VisualBasic.Logging;

namespace Punto9
{
    //Consigna: Permitir que el usuario elija su fecha de nacimiento.Mediante un Button,
    //calcular los años cumplidos restando la fecha elegida con DateTime.Now.Year y
    //mostrarlo en un Label.
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            dateTime.Now.Year - dateTimePicker1.Value.Year;
        }
    }
}
