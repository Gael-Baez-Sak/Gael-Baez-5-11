namespace Punto8
{
    //Consigna: Solicitar usuario y contraseña mediante TextBox(usando
    //UseSystemPasswordChar = true). Un CheckBox "Acepto términos" debe habilitar
    //(Enabled = true) el Button "Ingresar". Si la clave coincide con "admin123", mostrar
    //éxito en una Label; de lo contrario, mostrar advertencia.

    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();

            button1.Enabled = false;
        }

        private void button1_Click(object sender, EventArgs e)
        {

            if (textBox2.Text == "admin123")
            {
                label3.Text = "Sesion iniciada con exito";
            }
            else
            {
                label3.Text = "Contraseña incorrecta";
            }
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            button1.Enabled = checkBox1.Checked;
        }
    }
}
