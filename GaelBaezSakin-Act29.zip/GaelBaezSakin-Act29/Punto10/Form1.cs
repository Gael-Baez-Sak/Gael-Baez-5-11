using System.Diagnostics;

namespace Punto10
{
    //Consigna: Incluir un ComboBox con opciones: "Administrador","Editor" e "Invitado".
    //En el evento SelectedIndexChanged, modificar dinámicamente la propiedad Enabled
    //de tres CheckBox("Crear", "Modificar", "Eliminar") según el perfil elegido.
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();

            checkBox1.Enabled = false;
            checkBox2.Enabled = false;
            checkBox3.Enabled = false;
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBox1.SelectedItem == "Administrador")
            {
                checkBox1.Enabled = true;
                checkBox2.Enabled = true;
                checkBox3.Enabled = true;
            }
            if (comboBox1.SelectedItem == "Editor")
            {
                checkBox1.Enabled = false;
                checkBox2.Enabled = true;
                checkBox3.Enabled = false;
            }
            if (comboBox1.SelectedItem == "Invitado")
            {
                checkBox1.Enabled = false;
                checkBox2.Enabled = false;
                checkBox3.Enabled = false;
            }
        }
    }
}
