using static System.Runtime.InteropServices.JavaScript.JSType;

namespace Punto3
{
    //Solicitar el ingreso del nombre de una persona y seleccionar de un control
    //ComboBox un país.Al presionar un botón mostrar en la barra del título del
    //Form el nombre ingresado y el país seleccionado.
    internal static class Program
    {
        /// <summary>
        ///  The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            // To customize application configuration such as set high DPI settings or default font,
            // see https://aka.ms/applicationconfiguration.
            ApplicationConfiguration.Initialize();
            Application.Run(new Form1());
        }
    }
}