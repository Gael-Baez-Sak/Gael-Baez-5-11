using static System.Runtime.InteropServices.JavaScript.JSType;

namespace Punto3
{
    //Solicitar el ingreso del nombre de una persona y seleccionar de un control
    //ComboBox un país.Al presionar un botón mostrar en la barra del título del
    //Form el nombre ingresado y el país seleccionado.
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Text = textBox1.Text + ", " + comboBox1.Text;
        }
    }
}
