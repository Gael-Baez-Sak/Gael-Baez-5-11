using Microsoft.VisualBasic.Logging;

namespace Punto1
{
    //Disponer tres objetos de la clase CheckBox con nombres de navegadores web.
    //Cuando se presione un botón mostrar en el título del Form los programas
    //seleccionados.
    internal static class Program
    {
        /// <summary>
        ///  The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            // To customize application configuration such as set high DPI settings or default font,
            // see https://aka.ms/applicationconfiguration.
            ApplicationConfiguration.Initialize();
            Application.Run(new Form1());
        }
    }
}