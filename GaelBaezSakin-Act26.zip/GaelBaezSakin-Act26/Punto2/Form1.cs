using System.Net;

namespace Punto2
{
    //Permitir el ingreso de dos números en controles de tipo TextBox y mediante
    //dos controles de tipo RadioButton permitir seleccionar si queremos sumarlos o
    //restarlos.Al presionar un botón mostrar en el título del Form el resultado de la
    //operación.
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (radioButton1.Checked == true)
            {
                Text = textBox1.Text + " + " + textBox2.Text + " = " + (int.Parse(textBox1.Text) + int.Parse(textBox2.Text)).ToString();
            }
            if (radioButton2.Checked == true)
            {
                Text = textBox1.Text + " - " + textBox2.Text + " = " + (int.Parse(textBox1.Text) - int.Parse(textBox2.Text)).ToString();
            }
        }
    }
}
