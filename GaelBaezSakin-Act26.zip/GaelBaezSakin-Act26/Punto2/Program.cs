using System.Net;

namespace Punto2
{
    //Permitir el ingreso de dos números en controles de tipo TextBox y mediante
    //dos controles de tipo RadioButton permitir seleccionar si queremos sumarlos o
    //restarlos.Al presionar un botón mostrar en el título del Form el resultado de la
    //operación.
    internal static class Program
    {
        /// <summary>
        ///  The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            // To customize application configuration such as set high DPI settings or default font,
            // see https://aka.ms/applicationconfiguration.
            ApplicationConfiguration.Initialize();
            Application.Run(new Form1());
        }
    }
}