﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Punto4
{
    //● Investigación: Explicar el componente Timer(propiedades Interval, Enabled y
    //evento Tick) con un breve ejemplo explicativo.
    //● Consigna: Crear un mini - juego donde un Button cuente cuántos clics realiza el
    //usuario en 10 segundos.Al finalizar el tiempo mediante el Timer, deshabilitar el
    //botón(Enabled = false) y mostrar el puntaje acumulado en un MessageBox.Show.

    public partial class Form1 : Form
    {
        int clics = 0;
        int segundos = 0;
        public Form1()
        {
            InitializeComponent();

            timer1.Interval = 1000;
            timer1.Enabled = true;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            clics++;
        }

        private void timer1_Tick_1(object sender, EventArgs e)
        {
            segundos++;

            if (segundos == 10)
            {
                timer1.Enabled = false;
                button1.Enabled = false;

                MessageBox.Show("Puntaje: " + clics);
            }
        }
    }
}
