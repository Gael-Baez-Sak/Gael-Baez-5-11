﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Net.Mime.MediaTypeNames;
using static System.Net.WebRequestMethods;

namespace Punto5
{
//    Consigna: Cargar en un ComboBox tres opciones.Al cambiar la selección mediante
//el evento SelectedIndexChanged, mostrar la imagen correspondiente dentro del
//PictureBox.
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();

            pictureBox1.SizeMode = PictureBoxSizeMode.AutoSize;
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBox1.SelectedItem.ToString() == "Perro")
            { 
                pictureBox1.ImageLocation = "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRrRslH_GoJoXzq0x_Dxm7tE9PgK2k-4lMH_VB7MAChbA&s=10";
            } 
            else if (comboBox1.SelectedItem.ToString() == "Gato")
            { 
                pictureBox1.ImageLocation = "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSxZh-_j-trWyRCi7A45RQu-ENwFCoN97-uEVDubR1YnQ&s=10";
            }
            else if (comboBox1.SelectedItem.ToString() == "Conejo")
            { 
                pictureBox1.ImageLocation = "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ2r5QRzWnyVUVrrHLhw_Xodhla9CcF_IwunRvSzZh7Ig&s=10";
            }
        }
    }
}
