﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Punto5
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBox1.SelectedItem.ToString() == "Perro")
            { 
                pictureBox1.ImageLocation = "C:\\Users\\gaelb\\OneDrive\\Desktop\\POO\\Gael-Baez-5-11\\GaelBaezSakin-Act28\\Punto5\\Imagenes\\Perro.jpg";
            } 
            else if (comboBox1.SelectedItem.ToString() == "Gato")
            { 
                pictureBox1.ImageLocation = "C:\\Users\\gaelb\\OneDrive\\Desktop\\POO\\Gael-Baez-5-11\\GaelBaezSakin-Act28\\Punto5\\Imagenes\\Gato.jpg";
            }
            else if (comboBox1.SelectedItem.ToString() == "Conejo")
            { 
                pictureBox1.ImageLocation = "C:\\Users\\gaelb\\OneDrive\\Desktop\\POO\\Gael-Baez-5-11\\GaelBaezSakin-Act28\\Punto5\\Imagenes\\Conejo.jpg";
            }
        }
    }
}
