﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Net.Mime.MediaTypeNames;

namespace Punto5
{
//    Consigna: Cargar en un ComboBox tres opciones.Al cambiar la selección mediante
//el evento SelectedIndexChanged, mostrar la imagen correspondiente dentro del
//PictureBox.
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();

            pictureBox1.SizeMode = PictureBoxSizeMode.AutoSize;
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBox1.SelectedItem.ToString() == "Perro")
            { 
                pictureBox1.ImageLocation = "C:\\Users\\alumno.ET26\\source\\repos\\ACTIVIDADES-P.O.O-5-11-\\Gael-Baez-5-11\\Gael-Baez-5-11\\GaelBaezSakin-Act28\\Punto5\\Imagenes\\Perro.jpg";
            } 
            else if (comboBox1.SelectedItem.ToString() == "Gato")
            { 
                pictureBox1.ImageLocation = "C:\\Users\\alumno.ET26\\source\\repos\\ACTIVIDADES-P.O.O-5-11-\\Gael-Baez-5-11\\Gael-Baez-5-11\\GaelBaezSakin-Act28\\Punto5\\Imagenes\\Gato.jpg";
            }
            else if (comboBox1.SelectedItem.ToString() == "Conejo")
            { 
                pictureBox1.ImageLocation = "C:\\Users\\alumno.ET26\\source\\repos\\ACTIVIDADES-P.O.O-5-11-\\Gael-Baez-5-11\\Gael-Baez-5-11\\GaelBaezSakin-Act28\\Punto5\\Imagenes\\Conejo.jpg";
            }
        }
    }
}
