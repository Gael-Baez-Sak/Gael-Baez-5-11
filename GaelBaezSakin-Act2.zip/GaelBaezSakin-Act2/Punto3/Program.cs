﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Punto3
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //Se ingresa por teclado un número positivo de uno o dos dígitos (1..99) mostrar un mensaje indicando si el número tiene uno o dos dígitos.
            //(Tener en cuenta que condición debe cumplirse para tener dos dígitos, un número entero)

            int num1;
            string line;

            Console.Write("Ingrese un numero positivo del 1 al 99: ");
            line = Console.ReadLine();
            num1 = int.Parse(line);

            if (num1 >= 10) {
                Console.WriteLine("El numero es: " + num1);
                Console.WriteLine("El numero tiene dos (2) digitos ");
            }
            else{
                Console.WriteLine("El numero es: " + num1);
                Console.WriteLine("El numero tiene un (1) digito");
            }

            Console.ReadKey();
        }
    }
}
