﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Punto2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //Se ingresan seis notas de un alumno, si el promedio es mayor o igual a siete mostrar un mensaje "Promocionado"

            float nota1, nota2, nota3, nota4, nota5, nota6, promedio;
            string linea;

            Console.Write("Ingrese la primer nota: ");
            linea = Console.ReadLine();
            nota1 = float.Parse(linea);

            Console.Write("Ingrese la segunda nota: ");
            linea = Console.ReadLine();
            nota2 = float.Parse(linea);

            Console.Write("Ingrese la tercer nota: ");
            linea = Console.ReadLine();
            nota3 = float.Parse(linea);

            Console.Write("Ingrese la cuarta nota: ");
            linea = Console.ReadLine();
            nota4 = float.Parse(linea);

            Console.Write("Ingrese la quinta nota: ");
            linea = Console.ReadLine();
            nota5 = float.Parse(linea);

            Console.Write("Ingrese la sexta: ");
            linea = Console.ReadLine();
            nota6 = float.Parse(linea);


            promedio = (nota1 + nota2 + nota3 + nota4 + nota5 + nota6) / 6;
           

            if (promedio >= 7){
                Console.WriteLine("el promedio es: ");
                Console.WriteLine(promedio);
                Console.WriteLine("Promocionado");
            }

            Console.ReadKey();
        }
    }
}
