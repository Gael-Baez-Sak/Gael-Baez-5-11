﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Punto4
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //Se cargan por teclado tres números distintos. Mostrar por pantalla el mayor de ellos.

            int num1, num2, num3;
            string line;

            Console.Write("Ingrese el primer numero: ");
            line = Console.ReadLine();
            num1 = int.Parse(line);

            Console.Write("Ingrese el segundo numero: ");
            line = Console.ReadLine();
            num2 = int.Parse(line);

            Console.Write("Ingrese el tercer numero: ");
            line = Console.ReadLine();
            num3 = int.Parse(line);

            if (num1 > num2)
            {
                if (num1 > num3)
                {
                     Console.WriteLine("El mayor numero es: " + num1);
                }
            }
            if (num2 > num1)
            {
               if (num2 > num3)
               {
                    Console.WriteLine("El mayor numero es: " + num2);
               }
            }
            if (num3 > num1)
            {
                if (num3 > num2)
                {
                    Console.WriteLine("El mayor numero es: " + num3);
                }
            }

                Console.ReadKey();
            
        }
    }
}
