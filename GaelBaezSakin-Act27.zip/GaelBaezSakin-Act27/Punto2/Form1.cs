using Microsoft.VisualBasic.Logging;
using System.Collections;

namespace Punto2
{
    //Actividad 2: Encuesta de Preferencias de Música
    //Problema:
    //Una aplicación quiere conocer los gustos musicales de los usuarios.
    //Requisitos:
    //● Mostrar un ComboBox con 5 géneros musicales distintos.
    //● Incluir tres CheckBox que representen actividades relacionadas (por ejemplo:
    //&quot; Escuchar en vivo & quot;, &quot;Escuchar en streaming & quot;, &quot;Comprar discos&quot;).
    //● Al presionar un botón &quot; Mostrar Preferencias&quot;, en un Label se debe mostrar el género
    //seleccionado y las actividades marcadas.
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if(checkBox1.Checked == true)
            {
                label1.Text = "Elegiste: " + comboBox1.Text + " y Escuchar en vivo";
            }
            if (checkBox2.Checked == true)
            {
                label1.Text = "Elegiste: " + comboBox1.Text + " y Escuchar en streaming";
            }
            if (checkBox3.Checked == true)
            {
                label1.Text = "Elegiste: " + comboBox1.Text + " y Comprar disco";
            }
        }
    }
}
