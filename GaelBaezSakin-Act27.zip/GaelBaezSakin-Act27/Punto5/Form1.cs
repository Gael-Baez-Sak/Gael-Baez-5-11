using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.Button;

namespace Punto5
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (checkBox1.Checked == true)
            {
                label1.Text = "Resumen de la compra:   Tipo: " + comboBox1.Text + "        ----- Servicio adicional seleccionado: " + checkBox1.Text;
            }
            if (checkBox2.Checked == true)
            {
                label1.Text = "Resumen de la compra:   Tipo: " + comboBox1.Text + "        ----- Servicio adicional seleccionado: " + checkBox2.Text;
            }
        }
    }
}
