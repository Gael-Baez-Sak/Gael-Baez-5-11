using Microsoft.VisualBasic.Logging;
using Microsoft.Win32;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace Punto1
{
    //Actividad 1: Registro de Usuario Simple
    //Problema:
    //Se desea crear un formulario para registrar usuarios en un sistema.
    //Requisitos:
    //● Mostrar etiquetas(Label) para "Nombre", "Apellido" y "Correo".
    //● Permitir que el usuario escriba los datos en TextBox.
    //● Incluir un botón "Registrar" que, al presionarlo, muestra en un Label un mensaje con
    //los datos ingresados concatenados.
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            label4.Text = "usuario creado: " + "Nombre: " + textBox1.Text +  " Apellido: " + textBox2.Text + " Correo: " + textBox3.Text;
        }
    }
}
