using Microsoft.VisualBasic.ApplicationServices;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.Button;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.TrackBar;

namespace Punto3
{
    //Actividad 3: Elección de Paquete de Viaje
    //Problema:
    //Una agencia de viajes ofrece distintos tipos de paquetes turísticos.
    //Requisitos:
    //● Usar tres RadioButton para seleccionar el destino principal: "Playa", "Montaña" o
    //"Ciudad".

    //● Agregar un ComboBox para elegir la duración del viaje(ejemplo: "3 días", "7 días",
    //"15 días").
    //● Un botón "Confirmar" debe mostrar en un Label la opción seleccionada.
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (radioButton1.Checked == true)
            {
                label3.Text = "Elegiste: " + comboBox1.Text + " y " + radioButton1.Text;
            }
            if (radioButton2.Checked == true)
            {
                label3.Text = "Elegiste: " + comboBox1.Text + " y " + radioButton2.Text;
            }
            if (radioButton3.Checked == true)
            {
                label3.Text = "Elegiste: " + comboBox1.Text + " y " + radioButton3.Text;
            }
        }
    }
}
