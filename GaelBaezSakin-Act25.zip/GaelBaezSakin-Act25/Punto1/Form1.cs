using Microsoft.VisualBasic.Logging;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace Punto1
{
    //Elaborar una interfaz gráfica que muestre una calculadora(utilizar
    //objetos de la clase Button y un objeto de la clase TextBox donde se
    //mostrarían los resultados y se cargarían los datos), tener en cuenta que
    //solo se debe implementar la interfaz y no la funcionalidad de una
    //calculadora.
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {

        }

        private void button11_Click(object sender, EventArgs e)
        {

        }

        private void button10_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
