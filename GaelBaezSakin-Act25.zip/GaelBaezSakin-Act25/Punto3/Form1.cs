using static System.Runtime.InteropServices.JavaScript.JSType;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.TextBox;

namespace Punto3
{
    //Crear una aplicación que muestre en 6 objetos de la clase Label con
    //algunos nombres de controles visuales contenidos en la pestaña de
    //&quot; controles comunes&quot; del cuadro de herramientas
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
