﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Punto1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //Realizar un programa que pida cargar una fecha cualquiera, luego verificar si dicha fecha corresponde a Navidad.

            int dia, mes;
            string linea;

            Console.Write("introducir un dia (numero): ");
            linea = Console.ReadLine();
            dia = int.Parse(linea);
            Console.Write("introducir un mes (numero): ");
            linea = Console.ReadLine();
            mes = int.Parse(linea);

            if (dia == 25 && mes == 12)
            {
                Console.WriteLine("Ya es navidad :pp");
            } else
            {
                 Console.WriteLine("Todavia no es navidad :((");
            }


        }
    }
}
