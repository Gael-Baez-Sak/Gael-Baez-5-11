﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Punto5
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //Escribir un programa que pida ingresar la coordenada de un punto en el plano, es decir dos valores enteros x e y (distintos a cero).
            //Posteriormente imprimir en pantalla en que cuadrante se ubica dicho punto. (1º Cuadrante si x > 0 Y y > 0 , 2º Cuadrante: x < 0 Y y > 0). 

            int Valor1, Valor2;
            string linea;

            Console.Write("introduci un punto de coordenada (X No 0): ");
            linea = Console.ReadLine();
            Valor1 = int.Parse(linea);

            Console.Write("introduci un punto de coordenada (Y No 0): ");
            linea = Console.ReadLine();
            Valor2 = int.Parse(linea);

            if (Valor1 > 0 && Valor2 > 0) {
                Console.WriteLine("Las condenadas son: ");
                Console.WriteLine("X: " + Valor1);
                Console.WriteLine("Y: " + Valor2);
                Console.WriteLine("Por lo que se encuentra en el cuadrante 1 ");
            }
            if (Valor1 < 0 && Valor2 > 0)
            {
                Console.WriteLine("Las condenadas son: ");
                Console.WriteLine("X: " + Valor1);
                Console.WriteLine("Y: " + Valor2);
                Console.WriteLine("Por lo que se encuentra en el cuadrante 2 ");
            }
            Console.ReadKey();
        }
    }
}
